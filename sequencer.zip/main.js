// Create Namespaces
var sequencer = {},
    utils =     {};

/**
 * Project Data
 * @type {{}}
 */
sequencer.project = {};
/**
 * Project States
 * @type {{}}
 */
sequencer.project.state = {};
sequencer.project.state.activeTrack = null; // NOT USED YET
sequencer.project.state.activeNote = null;
sequencer.project.state.activeProject = null;

/**
 * Project Configuration
 * @type {{author: string, title: string, bpm: number}}
 */
sequencer.project.config = {
  author: 'Unknown',
  title: 'Untitled',
  bpm: 120
};


/**
 * Network related utilities and data loaders
 * @type {{}}
 */
utils.net = {};
/**
 * Loads Sequence Data from URL
 * @param sequenceURI URI of the project resource to load
 * @param callback function to handle response data
 */
utils.net.loadSequence = function(sequenceURI, callback) {
  var xhr = new XMLHttpRequest();
  xhr.overrideMimeType("application/json");
  xhr.open('GET', sequenceURI,true);
  xhr.addEventListener('error',function() {
    // TODO: Handle Error
  });
  xhr.addEventListener('load', function() {
      callback(xhr.responseText);
  });
  xhr.send(null);
};

/**
 *
 * @param sampleURI
 * @param callback
 */
utils.net.loadSample = function(sampleURI, callback) {
  var xhr = new XMLHttpRequest();
  xhr.open('GET', sampleURI,true);
  xhr.responseType = 'arraybuffer';
  xhr.addEventListener('error',function() {
    // TODO: Handle Error
  });
  xhr.addEventListener('load', function() {
    callback(xhr.response);
  })
};

// Math Utilities
/**
 * Math Utilities
 * @type {{Number}}
 */
utils.math = {};
/**
 * Calculate Note Duration based on Beats Per Minute
 * @param bpm
 * @returns {number}
 */
utils.math.calculateNoteTime = function(bpm) {
  return 60/bpm;
};

/**
 * Create View Elements
 * @type {{}}
 */
sequencer.render = {};
/**
 * Draw the project UI
 */
sequencer.render.project = function () {
  var container = document.getElementsByTagName('seq-project')[0];

  // destroy previous view
  while(container.firstChild) {
    container.removeChild(container.lastChild);
  }

  sequencer.render.projectTitle();
  sequencer.render.projectAuthor();

  var tracks = sequencer.project.state.activeProject.Tracks,
      tracksLength = tracks.length;
  var i = 0;
  for(i; i < tracksLength; ++i) {
    sequencer.render.track(tracks[i]);
  }
};
/**
 * Draws Project Title
 */
sequencer.render.projectTitle = function() {
  var container = document.getElementsByTagName('seq-project')[0],
      titleElement = document.createElement('seq-project-title'),
      titleText = document.createTextNode(sequencer.project.config.title);

  titleElement.appendChild(titleText);
  container.appendChild(titleElement);
};
/**
 * Draws Project Author
 */
sequencer.render.projectAuthor = function() {
  var container = document.getElementsByTagName('seq-project')[0],
      authorElement = document.createElement('seq-project-author'),
      authorText = document.createTextNode(sequencer.project.config.author);

  authorElement.appendChild(authorText);
  container.appendChild(authorElement);
};

/**
 * Draws a track with note trays, and populates notes if present in event list
 * @param trackConfig
 */
sequencer.render.track = function(trackConfig) {
  var trackContainer = document.getElementsByTagName('seq-project')[0],
      track = document.createElement('seq-track'),
      trackLabel = document.createElement('seq-track-label'),
      trackLabelContent = document.createTextNode(trackConfig.TrackName);

  trackContainer.appendChild(track);
  track.appendChild(trackLabel);
  track.trackData = trackConfig;
  trackLabel.style.gridColumnStart = 1;
  trackLabel.style.gridColumnEnd =1;
  trackLabel.appendChild(trackLabelContent);
  sequencer.render.noteTrays(track);
  sequencer.render.notes(track, trackConfig.Events);
};

/**
 * Draws Note Trays (empty note slots)
 * @param {Object} track target track
 */
sequencer.render.noteTrays = function(track) {
  var i = 2; // account for label column
  for (i; i <= 65; ++i) { // index starts at 1
    var tray = document.createElement('seq-note-tray');
    tray.sequencePosition = i-1;
    tray.style.gridColumnStart = i;
    tray.style.gridColumnEnd = i;
    tray.addEventListener('click',
        /**
         * Creates a note
         * @param event click event
         */
        function(event) {
          if(sequencer.project.state.activeNote !== null) {
            sequencer.edit.setNoteEventLength(event.currentTarget, track);
          } else {
            sequencer.edit.createNoteEvent(track, event.currentTarget.sequencePosition);
          }
        }, false);
    track.appendChild(tray);
  }
};
/**
 * Draws notes present in events list for a specified track
 * @param {Object} track target track
 * @param {Array} noteEvents note event details [start,end,pitch]
 */
sequencer.render.notes = function(track, noteEvents) {

  var noteEventLength = noteEvents.length;
  var i = 0;
  for (i; i < noteEventLength; ++i) {
    var noteData = noteEvents[i].split(':');
    var note = document.createElement('seq-note');
    note.style.gridColumnStart = parseInt(noteData[0])+1;
    note.style.gridColumnEnd = parseInt(noteData[0])+parseInt(noteData[1])+1;
    note.noteEvent = noteEvents[i]
    note.track = track;
    note.addEventListener('dblclick',
    /**
     * Selects a note
     * @param event double click event
     */
    function(event) {
      if(sequencer.project.state.activeNote!== null ||
          (sequencer.project.state.activeNote === event.currentTarget &&
            sequencer.project.state.activeNote !== null)) {
        sequencer.project.state.activeNote.classList.remove('selected');
        sequencer.project.state.activeNote = null;
      } else {
        sequencer.project.state.activeNote = event.currentTarget;
        event.currentTarget.classList.add('selected');
      }
    },false);
    note.pitchShift = noteData[2];
    track.appendChild(note);
  }
};

/**
 * Methods for editing the sequence
 * @type {{}}
 */
sequencer.edit = {};

/**
 * Insert a note to the project event list
 * @param track
 * @param position
 */
sequencer.edit.createNoteEvent = function(track, position) {
  var defaultDuration = 1, defaultPitch = 0;
  track.trackData.Events.push(position+':'+defaultDuration+":"+defaultPitch);
  sequencer.render.project();
};

/**
 * Sets a notes length in the project event list based on selection
 * @param target
 */
sequencer.edit.setNoteEventLength = function(target,track) {

  //FIXME:  This is a bit wonky way to do this, probably worth a revisit.

  var targetEvent = track.trackData.Events.indexOf(sequencer.project.state.activeNote.noteEvent);
  var event = sequencer.project.state.activeNote.noteEvent.split(':');

  if(target.sequencePosition > event[0]) {
    track.trackData.Events[targetEvent] = event[0] + ':' + ((target.sequencePosition - event[0])+1) + ':' + event[2];
    sequencer.project.state.activeNote = null;
    sequencer.render.project();
  }
};

/**
 * remove a note event based on event signature match
 */
sequencer.edit.deleteNoteEvent = function() {
  if(sequencer.project.state.activeNote !== null) {
    var targetEvent =
        sequencer.project.state.activeNote.track.trackData.Events.indexOf(sequencer.project.state.activeNote.noteEvent);
    sequencer.project.state.activeNote.track.trackData.Events.splice([targetEvent],1);
    sequencer.project.state.activeNote = null;
    sequencer.render.project();
  }
};

sequencer.audio = {};
sequencer.audio.audioContext = new AudioContext();

sequencer.audio.nodes = {};
sequencer.audio.nodes.compressor = sequencer.audio.audioContext.createDynamicsCompressor();
sequencer.audio.nodes.compressor.threshold.value = -30;
sequencer.audio.nodes.compressor.knee.value = 40;
sequencer.audio.nodes.compressor.ratio.value = 6;
sequencer.audio.nodes.compressor.attack.value = 0;
sequencer.audio.nodes.compressor.release.value = 0.4;

sequencer.audio.nodes.masterVolume = sequencer.audio.audioContext.createGain();
sequencer.audio.nodes.masterVolume.value = 1;

sequencer.audio.nodes.masterVolume.connect(sequencer.audio.audioContext.destination);
sequencer.audio.nodes.compressor.connect(sequencer.audio.nodes.masterVolume);

sequencer.audio.loadSample = function(sampleURI) {};    //TODO: use decodeAudio to create an audio buffer from URI
sequencer.audio.playSample = function(sample,pitch) {}; //TODO: play a loaded sample, or generate a oscillator
sequencer.audio.playSequence = function(eventList) {};  //TODO: trigger playback based on note event list offsets


/**
 * Initialize Sequencer
 */
sequencer.init = function() {
  utils.net.loadSequence('assets/test-data/test-project.json', function(response) {
    sequencer.project.state.activeProject = JSON.parse(response);
    sequencer.project.config.author = sequencer.project.state.activeProject.ProjectAuthor;
    sequencer.project.config.title = sequencer.project.state.activeProject.ProjectName;
    sequencer.project.config.bpm = sequencer.project.state.activeProject.ProjectBPM;
    sequencer.render.project();
  })
};

////////////////////// EVENT HANDLERS!!! //////////
document.addEventListener('DOMContentLoaded',sequencer.init,false);

/**
 * Capture Keyboard Events for NonPrintable Chars (ex. Delete, function keys)
 */
window.addEventListener('keyup', function(event) {
  if(event.keyCode === 46){ sequencer.edit.deleteNoteEvent();} // Delete Key
  if(event.keyCode === 8){ sequencer.edit.deleteNoteEvent();}  // Backspace Key (Delete on Mac)
});

/**
 * Capture Keyboard Events for printable chars (ex A-Z,1-0, etc)
 */
window.addEventListener('keypress', function(event) {
  // !!!NOTE: Period has the keyCode 46 on KeyPress and 190 on KeyUp this is important to pay
  // attention to due to the delete key having 46 as a keyCode on keyUp.
  if(event.keyCode === 122){ /* do something here */ }    // lowecase z
  if(event.keyCode === 120){ /* do something here */ }    // lowercase x
  if(event.keyCode === 99) { /* do something here */ }    // lowercase c
  if(event.keyCode === 118){ /* do something here */ }    // lowercase v
  if(event.keyCode === 98) { /* do something here */ }    // lowercase b
  if(event.keyCode === 110){ /* do something here */ }    // lowercase n
  if(event.keyCode === 109){ /* do something here */ }    // lowercase m
  if(event.keyCode === 44) { /* do something here */ }    // ,
  if(event.keyCode === 46) { /* do something here */ }    // .
  if(event.keyCode === 47) { /* do something here */ }    // /
});

