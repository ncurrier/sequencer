# Track Event Structure

>StartOffset : Duration : Pitch*

_only applies to generated sounds and not loaded audio files (buffers)_
