These samples are part of the free 808 Trapstep Vol 1. Sample Collection
Published by TRISAMPLES

www.trisamples.com

www.facebook.com/trisamples

www.twitter.com/trisamples
